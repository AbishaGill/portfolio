export const images = [
  "images/img-1.jpg",
  "images/img-2.jpg",
  "images/img-3.jpg",
  "images/img-4.jpg",
  "images/img-5.jpg",
];

export const flightOffers = [
  "✈️ 20% off on international flights – Limited time!",
  "💺 Free seat upgrade on business class bookings.",
  "🛄 Extra baggage allowance for frequent flyers.",
  "🏨 Flight + Hotel combo deals with 30% savings.",
  "🎟️ Buy one, get one free on select domestic routes.",
  "🚀 Earn double loyalty points on all bookings this month.",
];
